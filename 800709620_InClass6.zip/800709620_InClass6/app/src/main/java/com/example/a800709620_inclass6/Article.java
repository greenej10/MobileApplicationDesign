package com.example.a800709620_inclass6;

public class Article {
 String title;
 String publishedAt;
 String urToImage;
 String description;

 public Article()
 {

 }

    public String getTitle() {
        return title;
    }

    public String getPublishedAt() {
        return publishedAt;
    }

    public String getUrToImage() {
        return urToImage;
    }

    public String getDescription() {
        return description;
    }
}
