package com.example.a800709620_inclass08;

public interface FragmentCommunication {
    void respond(Expense expense);
    void delete(Expense expense);
}
